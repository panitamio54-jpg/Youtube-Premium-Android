# YouTube Premium Android v1.1

Aplicación Android independiente para la versión de Aislantes del Caribe.

- Nombre visible: **YouTube Premium**
- Paquete: `com.aislantes.youtubepremium`
- Página inicial: `https://teletop.online/Aislantesdelcaribe/?app=android`
- Admite reproducción web, búsqueda por voz, pantalla completa, PiP y Chromecast.

La aplicación se instala de forma independiente y no reemplaza TeleTop Video.


## Corrección de compilación v1.1

Se alinearon Kotlin 2.2.0, Android Gradle Plugin 8.10.1 y Gradle 8.11.1 para ser compatibles con Google Cast Framework 22.3.1.
