package com.aislantes.youtubepremium

import android.content.Context
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

class CastOptionsProvider : OptionsProvider {
    override fun getCastOptions(appContext: Context): CastOptions {
        val preferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val appId = preferences.getString(PREF_APP_ID, "").orEmpty().trim().uppercase()
        val namespace = preferences.getString(PREF_NAMESPACE, DEFAULT_NAMESPACE)
            .orEmpty()
            .ifBlank { DEFAULT_NAMESPACE }

        return CastOptions.Builder()
            .setReceiverApplicationId(appId)
            .setSupportedNamespaces(if (appId.isBlank()) emptyList() else listOf(namespace))
            .setEnableReconnectionService(true)
            .setResumeSavedSession(true)
            .setStopReceiverApplicationWhenEndingSession(true)
            .build()
    }

    override fun getAdditionalSessionProviders(appContext: Context): List<SessionProvider>? = null

    companion object {
        const val PREFS_NAME = "teletop_cast_v13"
        const val PREF_APP_ID = "cast_app_id"
        const val PREF_NAMESPACE = "cast_namespace"
        const val DEFAULT_NAMESPACE = "urn:x-cast:online.teletop.video"
    }
}
