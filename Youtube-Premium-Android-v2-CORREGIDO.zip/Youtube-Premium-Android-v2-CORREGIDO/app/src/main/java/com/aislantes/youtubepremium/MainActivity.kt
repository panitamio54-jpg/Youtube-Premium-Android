package com.aislantes.youtubepremium

import android.Manifest
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets as ComposeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.Locale

class MainActivity : FragmentActivity() {

    private var webView: WebView? = null
    private var pendingWebPermission: PermissionRequest? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var customViewContainer: FrameLayout? = null
    private lateinit var chromecastController: ChromecastController

    private var pageLoading by mutableStateOf(true)
    private var isVideoPlaying = false
    private var hasLoadedPlayer = false
    private var isShortVideo = false

    private val microphonePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val request = pendingWebPermission
        pendingWebPermission = null
        if (granted && request != null) {
            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
        } else {
            request?.deny()
            sendVoiceError("Permite el acceso al micrófono para buscar por voz.")
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* La app sigue funcionando aunque el usuario no muestre notificaciones. */ }

    private val voiceSearchLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                .orEmpty()

            if (text.isNotBlank()) sendVoiceResult(text)
            else sendVoiceError("No se detectó ninguna voz.")
        } else {
            sendVoiceError("Búsqueda por voz cancelada.")
        }
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = fileChooserCallback
        fileChooserCallback = null
        callback?.onReceiveValue(
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawableResource(android.R.color.black)
        chromecastController = ChromecastController(this) { webView }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        configureBackButton()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ComposeColor.Black)
                        .windowInsetsPadding(ComposeWindowInsets.safeDrawing)
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context -> createWebView(context) },
                        update = { view -> webView = view }
                    )

                    if (pageLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.align(Alignment.Center),
                            color = ComposeColor(0xFFFF003C)
                        )
                    }
                }
            }
        }
    }

    private fun createWebView(context: Context): WebView {
        return WebView(context).apply webViewSetup@ {
            setBackgroundColor(Color.BLACK)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadsImagesAutomatically = true
                allowContentAccess = true
                allowFileAccess = false
                javaScriptCanOpenWindowsAutomatically = true
                setSupportMultipleWindows(false)
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString = "$userAgentString YoutubePremiumAndroid/1.0"
            }

            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(this@webViewSetup, true)
            }

            if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val uri = request.url
                    return when (uri.scheme?.lowercase(Locale.ROOT)) {
                        "http", "https" -> false
                        else -> {
                            openExternalUri(uri)
                            true
                        }
                    }
                }

                override fun onPageFinished(view: WebView, url: String) {
                    pageLoading = false
                    installNativeHelpers(view)
                    view.post { updatePictureInPictureParams() }
                    super.onPageFinished(view, url)
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val requestsAudio = request.resources.contains(
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE
                        )
                        if (!requestsAudio) {
                            request.deny()
                            return@runOnUiThread
                        }

                        if (ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                        ) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        } else {
                            pendingWebPermission?.deny()
                            pendingWebPermission = request
                            microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    val chooserIntent = fileChooserParams?.createIntent()
                    if (chooserIntent == null) {
                        fileChooserCallback = null
                        return false
                    }
                    return try {
                        fileChooserLauncher.launch(chooserIntent)
                        true
                    } catch (_: ActivityNotFoundException) {
                        fileChooserCallback = null
                        Toast.makeText(
                            this@MainActivity,
                            "No se encontró un selector de archivos.",
                            Toast.LENGTH_SHORT
                        ).show()
                        false
                    }
                }

                override fun onShowCustomView(
                    view: View?,
                    callback: CustomViewCallback?
                ) {
                    if (view == null || callback == null) return
                    showFullscreenView(view, callback)
                }

                override fun onHideCustomView() {
                    hideFullscreenView()
                }
            }

            val bridge = TeleTopJavascriptBridge(this@MainActivity)
            addJavascriptInterface(bridge, "AndroidApp")
            addJavascriptInterface(bridge, "TeleTopAndroid")
            addJavascriptInterface(bridge, "Android")

            loadUrl(BuildConfig.WEB_URL)
            webView = this
        }
    }

    private fun installNativeHelpers(view: WebView) {
        val script = """
            (function(){
              if (window.__TELETOP_ANDROID_HELPERS_R2__) return;
              window.__TELETOP_ANDROID_HELPERS_R2__ = true;
              document.documentElement.classList.add('teletop-native-android');
              document.documentElement.classList.add('native-app');
              document.body && document.body.classList.add('native-app');
              window.__TELETOP_ANDROID__ = true;

              var style = document.getElementById('teletopAndroidR2Styles');
              if (!style) {
                style = document.createElement('style');
                style.id = 'teletopAndroidR2Styles';
                style.textContent = `
                  html.native-app .mobile-nav{
                    bottom:10px!important;
                    left:10px!important;
                    right:10px!important;
                    width:auto!important;
                    height:68px!important;
                    padding-bottom:0!important;
                    border-radius:18px!important;
                    overflow:hidden!important;
                  }
                  html.native-app .main{padding-bottom:104px!important}
                  html.android-pip-mode,html.android-pip-mode body{
                    margin:0!important;padding:0!important;overflow:hidden!important;background:#000!important;
                  }
                  html.android-pip-mode .topbar,
                  html.android-pip-mode .sidebar,
                  html.android-pip-mode .sidebar-backdrop,
                  html.android-pip-mode .mobile-nav,
                  html.android-pip-mode .quick-row,
                  html.android-pip-mode .discovery-strip,
                  html.android-pip-mode .smart-recommendations,
                  html.android-pip-mode .content-toolbar,
                  html.android-pip-mode .filters,
                  html.android-pip-mode .section-heading,
                  html.android-pip-mode .status,
                  html.android-pip-mode .grid,
                  html.android-pip-mode .load-more,
                  html.android-pip-mode .load-sentinel,
                  html.android-pip-mode .hero-text,
                  html.android-pip-mode .player-top-actions,
                  html.android-pip-mode .now-playing,
                  html.android-pip-mode .up-next-panel,
                  html.android-pip-mode .float-close,
                  html.android-pip-mode .float-back,
                  html.android-pip-mode .mini-player-bar{display:none!important}
                  html.android-pip-mode .main,
                  html.android-pip-mode .home-main{
                    position:fixed!important;inset:0!important;margin:0!important;padding:0!important;width:100vw!important;height:100vh!important;
                  }
                  html.android-pip-mode .home-hero,
                  html.android-pip-mode .hero,
                  html.android-pip-mode .hero.playing{
                    display:block!important;position:fixed!important;inset:0!important;margin:0!important;padding:0!important;
                    width:100vw!important;height:100vh!important;min-height:0!important;border:0!important;border-radius:0!important;background:#000!important;
                  }
                  html.android-pip-mode .player-area{
                    display:block!important;position:fixed!important;inset:0!important;margin:0!important;padding:0!important;
                    width:100vw!important;height:100vh!important;background:#000!important;
                  }
                  html.android-pip-mode .player-wrap{
                    display:block!important;position:absolute!important;inset:0!important;margin:0!important;padding:0!important;
                    width:100%!important;height:100%!important;border-radius:0!important;background:#000!important;
                  }
                  html.android-pip-mode .player-wrap iframe,
                  html.android-pip-mode #ytFrame{
                    position:absolute!important;inset:0!important;width:100%!important;height:100%!important;border:0!important;
                  }
                  html.android-pip-mode.android-pip-shorts .shorts-viewer.open{
                    display:block!important;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;
                  }
                `;
                document.head.appendChild(style);
              }

              function send(event, payload){
                payload = payload || {};
                try {
                  if (window.AndroidApp && typeof AndroidApp.onEvent === 'function') {
                    AndroidApp.onEvent(event, JSON.stringify(payload));
                    return;
                  }
                } catch(e) {}
                try {
                  if (window.AndroidApp && typeof AndroidApp.postMessage === 'function') {
                    AndroidApp.postMessage(JSON.stringify({event:event,payload:payload}));
                  }
                } catch(e) {}
              }

              var lastActive = null;
              function scanPlayer(){
                var frame = document.getElementById('ytFrame');
                var src = frame && (frame.getAttribute('src') || frame.src || '');
                var shorts = document.getElementById('shortsViewer');
                var shortsOpen = !!(shorts && shorts.classList.contains('open'));
                var active = shortsOpen || !!(frame && src && src !== 'about:blank' && src.indexOf('/embed/') !== -1);
                if (active !== lastActive) {
                  lastActive = active;
                  send('player-state', {active:active, mode:shortsOpen?'shorts':'normal'});
                }
              }

              window.addEventListener('play', function(){ send('video-play', {mode:'normal'}); }, true);
              window.addEventListener('pause', function(){ send('video-pause', {}); }, true);
              window.addEventListener('message', function(event){
                if (!event || !event.origin || event.origin.indexOf('youtube') === -1) return;
                var data = event.data;
                try { if (typeof data === 'string') data = JSON.parse(data); } catch(e) { return; }
                if (!data || data.event !== 'onStateChange') return;
                var state = Number(data.info);
                if (state === 1) send('video-play', {mode:'normal'});
                else if (state === 2) send('video-pause', {});
                else if (state === 0) send('video-ended', {});
              }, false);

              document.addEventListener('click', function(){ setTimeout(scanPlayer, 120); setTimeout(scanPlayer, 700); }, true);
              if (window.MutationObserver && document.documentElement) {
                new MutationObserver(scanPlayer).observe(document.documentElement, {subtree:true,childList:true,attributes:true,attributeFilter:['src','class']});
              }
              setInterval(scanPlayer, 1800);
              scanPlayer();

              window.addEventListener('teletop:pip-change', function(event){
                var detail = event && event.detail ? event.detail : {};
                var active = !!detail.active;
                document.documentElement.classList.toggle('android-pip-mode', active);
                document.documentElement.classList.toggle('android-pip-shorts', active && !!detail.shorts);
              });
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun configureBackButton() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    hideFullscreenView()
                    return
                }

                val view = webView
                if (view == null) {
                    finish()
                    return
                }

                view.evaluateJavascript(
                    "Boolean(window.androidBack && window.androidBack())"
                ) { result ->
                    when {
                        result == "true" -> Unit
                        view.canGoBack() -> view.goBack()
                        else -> finish()
                    }
                }
            }
        })
    }

    internal fun launchVoiceSearch(language: String?) {
        runOnUiThread {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE,
                    language?.takeIf { it.isNotBlank() } ?: Locale.getDefault().toLanguageTag()
                )
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Di el video, artista o tema")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            try {
                voiceSearchLauncher.launch(intent)
            } catch (_: ActivityNotFoundException) {
                sendVoiceError("Este teléfono no tiene reconocimiento de voz disponible.")
            }
        }
    }

    private fun sendVoiceResult(text: String) {
        val quoted = JSONObject.quote(text)
        webView?.evaluateJavascript(
            "window.TeleTopVoiceSearch && window.TeleTopVoiceSearch.receiveResult($quoted);",
            null
        )
    }

    private fun sendVoiceError(message: String) {
        val quoted = JSONObject.quote(message)
        webView?.evaluateJavascript(
            "window.TeleTopVoiceSearch && window.TeleTopVoiceSearch.receiveError($quoted);",
            null
        )
    }


    internal fun configureChromecast(appId: String, namespace: String?) {
        chromecastController.configure(appId, namespace)
    }

    internal fun openChromecastDialog(payloadJson: String?) {
        chromecastController.openDialog(payloadJson)
    }

    internal fun sendToChromecast(payloadJson: String?) {
        chromecastController.send(payloadJson)
    }

    internal fun isChromecastConnected(): Boolean = chromecastController.isConnected()

    internal fun handleWebMessage(message: String) {
        runOnUiThread {
            try {
                val root = JSONObject(message)
                val event = root.optString("event")
                val payload = root.optJSONObject("payload") ?: JSONObject()
                handleWebEvent(event, payload)
            } catch (error: Exception) {
                Log.w(TAG, "Mensaje web inválido", error)
            }
        }
    }

    internal fun handleWebEvent(event: String, payloadJson: String?) {
        runOnUiThread {
            val payload = try {
                JSONObject(payloadJson ?: "{}")
            } catch (_: Exception) {
                JSONObject()
            }
            handleWebEvent(event, payload)
        }
    }

    private fun handleWebEvent(event: String, payload: JSONObject) {
        when (event) {
            "video-play" -> {
                isVideoPlaying = true
                hasLoadedPlayer = true
                isShortVideo = payload.optString("mode") == "shorts"
                startPlaybackKeepAlive()
                updatePictureInPictureParams()
            }

            "video-pause", "video-ended" -> {
                isVideoPlaying = false
                updatePictureInPictureParams()
            }

            "player-state" -> {
                hasLoadedPlayer = payload.optBoolean("active", false)
                isShortVideo = payload.optString("mode") == "shorts"
                if (hasLoadedPlayer) startPlaybackKeepAlive() else stopPlaybackKeepAlive()
                updatePictureInPictureParams()
            }

            "share" -> shareVideo(payload)
            "network-offline" -> Toast.makeText(
                this,
                "Sin conexión a internet",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun startPlaybackKeepAlive() {
        val intent = Intent(this, PlaybackKeepAliveService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopPlaybackKeepAlive() {
        if (!hasLoadedPlayer && !isVideoPlaying) {
            stopService(Intent(this, PlaybackKeepAliveService::class.java))
        }
    }

    private fun shareVideo(payload: JSONObject) {
        val title = payload.optString("title", "Video")
        val url = payload.optString("url")
        val text = listOf(title, url).filter { it.isNotBlank() }.joinToString("\n")
        if (text.isBlank()) return

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(shareIntent, "Compartir video"))
    }

    private fun canUsePictureInPicture(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    }

    private fun playerAvailable(): Boolean = isVideoPlaying || hasLoadedPlayer

    private fun buildPictureInPictureParams(): PictureInPictureParams {
        val aspect = if (isShortVideo) Rational(9, 16) else Rational(16, 9)
        val builder = PictureInPictureParams.Builder().setAspectRatio(aspect)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(playerAvailable())
            builder.setSeamlessResizeEnabled(true)
        }

        webView?.let { view ->
            val rect = Rect()
            if (view.getGlobalVisibleRect(rect) && !rect.isEmpty) {
                builder.setSourceRectHint(rect)
            }
        }
        return builder.build()
    }

    private fun updatePictureInPictureParams() {
        if (!canUsePictureInPicture()) return
        try {
            setPictureInPictureParams(buildPictureInPictureParams())
        } catch (error: Exception) {
            Log.w(TAG, "No se pudieron actualizar los parámetros PiP", error)
        }
    }

    private fun enterPictureInPictureNow(): Boolean {
        if (!canUsePictureInPicture() || !playerAvailable() || customView != null || isInPictureInPictureMode) {
            return false
        }

        val shortsValue = if (isShortVideo) "true" else "false"
        webView?.evaluateJavascript(
            "window.dispatchEvent(new CustomEvent('teletop:pip-change',{detail:{active:true,shorts:$shortsValue}}));",
            null
        )

        return try {
            enterPictureInPictureMode(buildPictureInPictureParams())
        } catch (error: Exception) {
            Log.w(TAG, "No se pudo activar PiP", error)
            false
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        enterPictureInPictureNow()
    }

    override fun onPictureInPictureRequested(): Boolean {
        return enterPictureInPictureNow() || super.onPictureInPictureRequested()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val value = if (isInPictureInPictureMode) "true" else "false"
        val shortsValue = if (isShortVideo) "true" else "false"
        webView?.evaluateJavascript(
            "window.dispatchEvent(new CustomEvent('teletop:pip-change',{detail:{active:$value,shorts:$shortsValue}}));",
            null
        )
    }

    private fun showFullscreenView(
        view: View,
        callback: WebChromeClient.CustomViewCallback
    ) {
        if (customView != null) {
            callback.onCustomViewHidden()
            return
        }

        customView = view
        customViewCallback = callback
        webView?.visibility = View.GONE

        val content = findViewById<FrameLayout>(android.R.id.content)
        customViewContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
        content.addView(
            customViewContainer,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(
                WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
            )
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
    }

    private fun hideFullscreenView() {
        val content = findViewById<FrameLayout>(android.R.id.content)
        customViewContainer?.let(content::removeView)
        customViewContainer = null
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        webView?.visibility = View.VISIBLE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.show(
                WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
            )
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    private fun openExternalUri(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No se puede abrir este enlace.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
        webView?.resumeTimers()
        updatePictureInPictureParams()
    }

    override fun onPause() {
        if (playerAvailable()) {
            webView?.onResume()
            webView?.resumeTimers()
        }
        super.onPause()
    }

    override fun onStop() {
        if (playerAvailable()) {
            webView?.onResume()
            webView?.resumeTimers()
        }
        super.onStop()
    }

    override fun onDestroy() {
        chromecastController.destroy()
        pendingWebPermission?.deny()
        pendingWebPermission = null
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null

        if (isFinishing) {
            stopService(Intent(this, PlaybackKeepAliveService::class.java))
            webView?.apply {
                loadUrl("about:blank")
                stopLoading()
                removeAllViews()
                destroy()
            }
            webView = null
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "YoutubePremium"
    }
}

class TeleTopJavascriptBridge(activity: MainActivity) {
    private val activityRef = WeakReference(activity)

    @JavascriptInterface
    fun startVoiceSearch(language: String?) {
        activityRef.get()?.launchVoiceSearch(language)
    }

    @JavascriptInterface
    fun requestVoiceSearch(language: String?) {
        activityRef.get()?.launchVoiceSearch(language)
    }


    @JavascriptInterface
    fun configureCast(appId: String, namespace: String?) {
        activityRef.get()?.configureChromecast(appId, namespace)
    }

    @JavascriptInterface
    fun openCastDialog(payloadJson: String?) {
        activityRef.get()?.openChromecastDialog(payloadJson)
    }

    @JavascriptInterface
    fun sendToChromecast(payloadJson: String?) {
        activityRef.get()?.sendToChromecast(payloadJson)
    }

    @JavascriptInterface
    fun isCastConnected(): Boolean {
        return activityRef.get()?.isChromecastConnected() == true
    }

    @JavascriptInterface
    fun postMessage(message: String) {
        activityRef.get()?.handleWebMessage(message)
    }

    @JavascriptInterface
    fun onEvent(event: String, payloadJson: String?) {
        activityRef.get()?.handleWebEvent(event, payloadJson)
    }

    @JavascriptInterface
    fun notify(message: String) {
        activityRef.get()?.handleWebMessage(message)
    }
}
