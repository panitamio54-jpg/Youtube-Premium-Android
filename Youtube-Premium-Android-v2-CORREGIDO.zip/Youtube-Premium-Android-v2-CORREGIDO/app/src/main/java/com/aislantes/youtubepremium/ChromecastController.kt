package com.aislantes.youtubepremium

import android.content.Context
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.fragment.app.FragmentActivity
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.Cast
import com.google.android.gms.cast.CastDevice
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import org.json.JSONObject
import java.io.IOException

class ChromecastController(
    private val activity: FragmentActivity,
    private val webViewProvider: () -> WebView?
) {
    private var castContext: CastContext? = null
    private var mediaRouteButton: MediaRouteButton? = null
    private var activeSession: CastSession? = null
    private var appId: String = ""
    private var namespace: String = CastOptionsProvider.DEFAULT_NAMESPACE
    private var pendingPayload: JSONObject? = null
    private var initialized = false

    private val messageCallback = Cast.MessageReceivedCallback {
            _: CastDevice,
            _: String,
            message: String ->
        handleReceiverMessage(message)
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(session: CastSession) {
            notifyWeb("connecting", "Abriendo YouTube Premium en el televisor…")
        }

        override fun onSessionStarted(session: CastSession, sessionId: String) {
            attachSession(session, "connected")
        }

        override fun onSessionStartFailed(session: CastSession, error: Int) {
            activeSession = null
            notifyWeb("failed", "No fue posible iniciar Chromecast. Código: $error")
        }

        override fun onSessionEnding(session: CastSession) {
            notifyWeb("ending", "Desconectando Chromecast…")
        }

        override fun onSessionEnded(session: CastSession, error: Int) {
            detachSession(session)
            activeSession = null
            notifyWeb("disconnected", "Chromecast desconectado")
        }

        override fun onSessionResuming(session: CastSession, sessionId: String) {
            notifyWeb("connecting", "Recuperando conexión con Chromecast…")
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            attachSession(session, "resumed")
        }

        override fun onSessionResumeFailed(session: CastSession, error: Int) {
            activeSession = null
            notifyWeb("failed", "No fue posible recuperar Chromecast. Código: $error")
        }

        override fun onSessionSuspended(session: CastSession, reason: Int) {
            notifyWeb("suspended", "Conexión con Chromecast suspendida")
        }
    }

    fun configure(receiverAppId: String, customNamespace: String?) {
        activity.runOnUiThread {
            val normalizedAppId = receiverAppId.trim().uppercase()
            val normalizedNamespace = customNamespace
                ?.trim()
                ?.takeIf { it.startsWith("urn:x-cast:") }
                ?: CastOptionsProvider.DEFAULT_NAMESPACE

            if (!normalizedAppId.matches(Regex("^[A-F0-9]{8}$"))) {
                notifyWeb("failed", "Chromecast todavía no está configurado por el administrador.")
                return@runOnUiThread
            }

            val preferences = activity.getSharedPreferences(
                CastOptionsProvider.PREFS_NAME,
                Context.MODE_PRIVATE
            )
            val previousAppId = preferences.getString(CastOptionsProvider.PREF_APP_ID, "").orEmpty()
            preferences.edit()
                .putString(CastOptionsProvider.PREF_APP_ID, normalizedAppId)
                .putString(CastOptionsProvider.PREF_NAMESPACE, normalizedNamespace)
                .apply()

            appId = normalizedAppId
            namespace = normalizedNamespace

            if (initialized && previousAppId.isNotBlank() && previousAppId != normalizedAppId) {
                notifyWeb(
                    "restart_required",
                    "La configuración Chromecast cambió. Cierra y abre nuevamente la aplicación."
                )
                return@runOnUiThread
            }

            initializeIfNeeded()
        }
    }

    fun openDialog(payloadJson: String?) {
        activity.runOnUiThread {
            val payload = parsePayload(payloadJson)
            if (payload == null) {
                notifyWeb("failed", "Primero reproduce un video válido.")
                return@runOnUiThread
            }
            pendingPayload = payload

            if (!initialized) {
                if (appId.isBlank()) {
                    notifyWeb("failed", "Chromecast todavía no está activado.")
                    return@runOnUiThread
                }
                initializeIfNeeded()
            }

            val session = castContext?.sessionManager?.currentCastSession
            if (session?.isConnected == true) {
                attachSession(session, "connected")
                sendPendingPayload()
                return@runOnUiThread
            }

            val button = mediaRouteButton
            if (button == null) {
                notifyWeb("failed", "No se pudo abrir el selector Chromecast.")
                return@runOnUiThread
            }

            notifyWeb("connecting", "Buscando televisores compatibles…")
            button.visibility = View.VISIBLE
            button.isEnabled = true
            val clicked = button.performClick()
            if (!clicked) {
                notifyWeb("failed", "No se pudo abrir el selector de dispositivos.")
            }
        }
    }

    fun send(payloadJson: String?) {
        activity.runOnUiThread {
            pendingPayload = parsePayload(payloadJson)
            if (pendingPayload == null) {
                notifyWeb("failed", "El video no es válido.")
                return@runOnUiThread
            }
            sendPendingPayload()
        }
    }

    fun isConnected(): Boolean = activeSession?.isConnected == true

    private fun initializeIfNeeded() {
        if (initialized) return
        if (appId.isBlank()) return

        try {
            val context = CastContext.getSharedInstance(activity)
            castContext = context
            context.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)

            val button = MediaRouteButton(activity).apply {
                id = View.generateViewId()
                alpha = 0f
                visibility = View.VISIBLE
                isClickable = true
                isFocusable = true
                contentDescription = "Seleccionar dispositivo Chromecast"
            }

            // El botón debe permanecer adjunto y dentro de la ventana para que
            // MediaRouteButton pueda abrir correctamente el selector nativo.
            // Se deja en 1×1 px y transparente porque la interfaz visible vive
            // dentro de la página web.
            val params = FrameLayout.LayoutParams(1, 1, Gravity.TOP or Gravity.END)
            val content = activity.findViewById<FrameLayout>(android.R.id.content)
            content.addView(button, params)
            CastButtonFactory.setUpMediaRouteButton(activity.applicationContext, button)
            mediaRouteButton = button
            initialized = true

            context.sessionManager.currentCastSession?.let { session ->
                if (session.isConnected) attachSession(session, "resumed")
            }
            notifyWeb("ready", "Chromecast listo")
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo inicializar Google Cast", error)
            notifyWeb("failed", "Google Cast no está disponible en este dispositivo.")
        }
    }

    private fun attachSession(session: CastSession, status: String) {
        activeSession?.takeIf { it !== session }?.let(::detachSession)
        activeSession = session
        try {
            session.setMessageReceivedCallbacks(namespace, messageCallback)
        } catch (error: IOException) {
            Log.w(TAG, "No se pudo registrar el canal Cast", error)
        }

        val deviceName = session.castDevice?.friendlyName.orEmpty()
        notifyWeb(status, "Conectado a ${deviceName.ifBlank { "Chromecast" }}", deviceName)
        sendPendingPayload()
    }

    private fun detachSession(session: CastSession) {
        try {
            session.removeMessageReceivedCallbacks(namespace)
        } catch (_: Exception) {
        }
    }

    private fun sendPendingPayload() {
        val payload = pendingPayload ?: return
        val session = activeSession ?: castContext?.sessionManager?.currentCastSession
        if (session?.isConnected != true) {
            notifyWeb("failed", "Selecciona primero un televisor Chromecast.")
            return
        }

        activeSession = session
        payload.put("type", "LOAD")
        payload.put("sender", "android")
        payload.put("sentAt", System.currentTimeMillis())

        try {
            val pendingResult = session.sendMessage(namespace, payload.toString())
            if (pendingResult == null) {
                notifyWeb("failed", "La sesión Chromecast no está disponible.")
                return
            }
            pendingResult.setResultCallback { result ->
                if (result.isSuccess) {
                    val deviceName = session.castDevice?.friendlyName.orEmpty()
                    pendingPayload = null
                    notifyWeb("sent", "Video enviado al televisor", deviceName)
                } else {
                    notifyWeb(
                        "failed",
                        "No fue posible enviar el video. Código: ${result.statusCode}"
                    )
                }
            }
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo enviar el video a Chromecast", error)
            notifyWeb("failed", "No fue posible enviar el video a Chromecast.")
        }
    }

    private fun parsePayload(raw: String?): JSONObject? {
        val payload = try {
            JSONObject(raw ?: "{}")
        } catch (_: Exception) {
            return null
        }
        val videoId = payload.optString("videoId").trim()
        if (!videoId.matches(Regex("^[A-Za-z0-9_-]{11}$"))) return null
        if (!payload.has("title")) payload.put("title", "Video de YouTube")
        if (!payload.has("channel")) payload.put("channel", "YouTube")
        if (!payload.has("autoplay")) payload.put("autoplay", true)
        return payload
    }

    private fun handleReceiverMessage(message: String) {
        val payload = try {
            JSONObject(message)
        } catch (_: Exception) {
            JSONObject().put("status", "receiver_message").put("message", message)
        }
        if (!payload.has("status")) payload.put("status", "receiver_status")
        notifyWebPayload(payload)
    }

    private fun notifyWeb(status: String, message: String, deviceName: String = "") {
        val payload = JSONObject()
            .put("status", status)
            .put("message", message)
            .put("deviceName", deviceName)
        notifyWebPayload(payload)
    }

    private fun notifyWebPayload(payload: JSONObject) {
        val quoted = JSONObject.quote(payload.toString())
        webViewProvider()?.post {
            webViewProvider()?.evaluateJavascript(
                "window.TeleTopChromecast&&window.TeleTopChromecast.receiveNativeStatus($quoted);",
                null
            )
        }
    }

    fun destroy() {
        activity.runOnUiThread {
            activeSession?.let(::detachSession)
            castContext?.sessionManager?.removeSessionManagerListener(
                sessionListener,
                CastSession::class.java
            )
            mediaRouteButton?.let { button ->
                (button.parent as? FrameLayout)?.removeView(button)
            }
            mediaRouteButton = null
            activeSession = null
            castContext = null
            initialized = false
        }
    }

    companion object {
        private const val TAG = "TeleTopChromecast"
    }
}
