-keepclassmembers class com.aislantes.youtubepremium.TeleTopJavascriptBridge {
    @android.webkit.JavascriptInterface <methods>;
}
