@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)

set VERSION=8.10.2
set CACHE_DIR=%USERPROFILE%\.gradle\teletop-gradle
set INSTALL_DIR=%CACHE_DIR%\gradle-%VERSION%
set ZIP_FILE=%CACHE_DIR%\gradle-%VERSION%-bin.zip

if not exist "%INSTALL_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP_FILE%'; Expand-Archive -Force '%ZIP_FILE%' '%CACHE_DIR%'"
  if errorlevel 1 exit /b 1
)

call "%INSTALL_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
