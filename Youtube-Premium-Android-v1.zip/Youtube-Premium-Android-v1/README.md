# YouTube Premium Android v1.0

Aplicación Android independiente para la versión de Aislantes del Caribe.

- Nombre visible: **YouTube Premium**
- Paquete: `com.aislantes.youtubepremium`
- Página inicial: `https://teletop.online/Aislantesdelcaribe/?app=android`
- Admite reproducción web, búsqueda por voz, pantalla completa, PiP y Chromecast.

La aplicación se instala de forma independiente y no reemplaza TeleTop Video.
